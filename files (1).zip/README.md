# devfolio — Alex Rivera's Developer Portfolio

A single-page, responsive developer portfolio built with plain HTML and CSS —
no frameworks, no build step. It's the capstone project for Modules 1–2:
semantic structure, a CSS variable-based colour/type system, Flexbox, CSS
Grid, and a responsive breakpoint, all shipped to a live GitHub Pages URL.

## Live site

🔗 **https://your-username.github.io/devfolio/**

## Preview

| Mobile (1 column) | Desktop (3 columns) |
|---|---|
| Nav stays in a usable Flexbox row; project cards stack in a single column. | Project grid expands to a 3-column CSS Grid at wider widths. |

## Run it locally

No build tools or dependencies needed.

```bash
git clone https://github.com/your-username/devfolio.git
cd devfolio
```

Then either:

- Double-click `index.html` to open it directly in a browser, **or**
- Serve it locally so relative paths behave exactly like production:

  ```bash
  # Python 3
  python3 -m http.server 8000
  # then open http://localhost:8000
  ```

## What's inside

```
devfolio/
├── index.html   # semantic markup: header/nav, main (about + projects), footer/contact
├── style.css    # CSS variables (colour + type system), Flexbox header, Grid projects, media queries
└── README.md    # this file
```

## Tech / techniques used

- Semantic HTML5 (`<header>`, `<nav>`, `<main>`, `<section>`, `<footer>`, `<article>`)
- CSS custom properties for a consistent colour + type system (`--brand`, `--ink`, `--paper`, …)
- Flexbox for the header/nav row and the about layout at wider widths
- CSS Grid for the responsive project card grid (1 → 2 → 3 columns)
- Two `@media (min-width: …)` breakpoints (600px, 900px) for layout changes
- `img { max-width: 100%; height: auto; }` so any image stays inside the viewport on mobile

## Deploying (GitHub Pages)

1. Push this repo to GitHub with `index.html` at the repo root.
2. Go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Branch: `main`, folder: `/ (root)` → **Save**.
5. Wait ~1 minute, then visit `https://your-username.github.io/devfolio/`.

## Author

**Alex Rivera**
- Email: alex.rivera.dev@example.com
- GitHub: [github.com/your-username](https://github.com/your-username)
- LinkedIn: [linkedin.com/in/your-username](https://www.linkedin.com/in/your-username)
